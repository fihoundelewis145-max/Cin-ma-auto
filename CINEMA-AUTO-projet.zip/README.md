# CINEMA AUTO

Application Node.js de gestion et d'envoi vers YouTube de vidéos que l'utilisateur est autorisé à publier.

## Lancer en local
1. Installer Node.js 20+.
2. `npm install`
3. Définir `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` et `GOOGLE_REDIRECT_URI`.
4. `npm start`, puis ouvrir http://localhost:3000.

## Google OAuth
Dans Google Cloud Console, activer YouTube Data API v3, configurer l'écran de consentement OAuth et ajouter l'URL de redirection :
`https://VOTRE-SERVICE.onrender.com/auth/youtube/callback`

## Déployer sur Render
1. Créer un Blueprint depuis ce dépôt GitHub.
2. Render détecte `render.yaml` et crée le service.
3. Ajouter les variables Google OAuth dans les paramètres du service.

## À terminer avant une vraie production
- Les jetons OAuth sont actuellement conservés en mémoire : prévoir une base de données et un chiffrement persistant.
- Les fichiers temporaires ne sont pas un stockage durable : prévoir un stockage objet ou disque persistant.
- Ajouter authentification administrateur, file de tâches persistante, journalisation, reprise après échec et tests.
- La publication YouTube est configurée en privé par défaut.
- Ne publier que des contenus pour lesquels vous détenez les droits de redistribution.
