require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const multer = require("multer");
const { google } = require("googleapis");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const uploadDir = path.join(__dirname, "uploads");
fs.mkdirSync(uploadDir, { recursive: true });

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 60 }));
app.use(express.static(path.join(__dirname, "public")));

const upload = multer({
  dest: uploadDir,
  limits: { fileSize: 2 * 1024 * 1024 * 1024 },
  fileFilter: (_req, file, cb) =>
    file.mimetype.startsWith("video/") ? cb(null, true) : cb(new Error("Fichier vidéo requis"))
});

let youtubeTokens = null;
function oauth() {
  const { GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REDIRECT_URI } = process.env;
  if (!GOOGLE_CLIENT_ID || !GOOGLE_CLIENT_SECRET || !GOOGLE_REDIRECT_URI) return null;
  return new google.auth.OAuth2(GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REDIRECT_URI);
}

app.get("/api/health", (_req, res) => res.json({ ok: true, app: "CINEMA AUTO" }));
app.get("/api/status", (_req, res) => res.json({
  youtubeConfigured: Boolean(oauth()),
  youtubeConnected: Boolean(youtubeTokens),
  uploadMode: "private"
}));

app.get("/auth/youtube", (_req, res) => {
  const client = oauth();
  if (!client) return res.status(503).send("Configurez les variables Google OAuth dans Render.");
  res.redirect(client.generateAuthUrl({
    access_type: "offline",
    prompt: "consent",
    scope: ["https://www.googleapis.com/auth/youtube.upload"]
  }));
});

app.get("/auth/youtube/callback", async (req, res) => {
  try {
    const client = oauth();
    if (!client || !req.query.code) return res.status(400).send("Autorisation Google incomplète.");
    const { tokens } = await client.getToken(req.query.code);
    youtubeTokens = tokens; // Démonstration : stocker les jetons chiffrés en base avant production.
    res.redirect("/?youtube=connected");
  } catch (error) {
    console.error(error);
    res.status(500).send("Connexion YouTube échouée. Vérifiez la configuration OAuth.");
  }
});

app.post("/api/youtube/upload", upload.single("video"), async (req, res) => {
  const temp = req.file?.path;
  try {
    if (!youtubeTokens) return res.status(401).json({ error: "Connectez d'abord YouTube." });
    if (req.body.rightsConfirmed !== "true")
      return res.status(400).json({ error: "Confirmez vos droits de publication." });
    const title = String(req.body.title || "").trim().slice(0, 100);
    if (!title || !req.file) return res.status(400).json({ error: "Titre et vidéo obligatoires." });

    const client = oauth();
    client.setCredentials(youtubeTokens);
    const yt = google.youtube({ version: "v3", auth: client });
    const result = await yt.videos.insert({
      part: ["snippet", "status"],
      requestBody: {
        snippet: {
          title,
          description: String(req.body.description || "").slice(0, 5000),
          categoryId: "22"
        },
        status: { privacyStatus: "private", selfDeclaredMadeForKids: false }
      },
      media: { body: fs.createReadStream(temp) }
    });
    res.json({
      ok: true,
      videoId: result.data.id,
      url: "https://www.youtube.com/watch?v=" + result.data.id,
      privacyStatus: "private"
    });
  } catch (error) {
    console.error("YouTube upload error:", error.message);
    res.status(500).json({ error: "Échec de l'envoi. Vérifiez les autorisations et quotas YouTube." });
  } finally {
    if (temp && fs.existsSync(temp)) fs.unlinkSync(temp);
  }
});

app.use((err, _req, res, _next) => res.status(400).json({ error: err.message }));
app.listen(PORT, () => console.log(`CINEMA AUTO lancé sur le port ${PORT}`));
